host = '47.254.80.41';	// hostname or IP address
port = 9001;
topic = 'WenDu';		// topic to subscribe to
useTLS = false;
username = null;
password = null;
cleansession = true;
